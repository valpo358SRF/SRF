package com.example.flutter_showcase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
