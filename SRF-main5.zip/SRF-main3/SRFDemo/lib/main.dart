
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(MyApp());

///runs the entire program. Basically a main function
/// This is the main application widget.
class MyApp extends StatelessWidget {
  static const String _title = 'Flutter SERF Demo';

  @override
  Widget build(BuildContext context) {
    ///builds a blank app with an internal title and an amber background
    return MaterialApp(
      title: _title,
      theme: new ThemeData(scaffoldBackgroundColor: Colors.brown[100]),
      home: MyStatefulWidget(),
      ///this is what links it to a non static app
    );
  }
}

/// This is the stateful widget that the main application instantiates.
class MyStatefulWidget extends StatefulWidget {
  MyStatefulWidget({Key key}) : super(key: key);
  @override
  _MyStatefulWidgetState createState() => _MyStatefulWidgetState();
  ///this class calls the state to be built and returned
}
/// This is the private State class that goes with MyStatefulWidget.
class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  int _selectedIndex = 0;
  ///index int
  static const TextStyle optionStyle =
      TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  ///text styling
  ///this is a list of widgets to be selected. The widgets are separated by commas
  List<Widget> _widgetOptions = <Widget>[
    Column(
      ///widget 1
      mainAxisAlignment: MainAxisAlignment.center,
      ///sets all column children to the center of the typical y axis
      children: <Widget>[
        ///list of all children cast as widgets to ensure they are
        Container(
            ///blank container used for background colors and spacing
            color: Colors.amber,
            alignment: Alignment.center,
            height: 200.0,
            width: 400.0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'Is the SERF Running?',
                  style: optionStyle,
                ),
                Container(
                  ///blank container for spacing
                  height: 18.0,
                ),
                Text(
                  'Yes     |     No',
                  style: optionStyle,
                ),
              ],
            )

        ),
        Container(
          ///this container is used for padding. It could just be text without a padding need
          padding: new EdgeInsets.all(10.0),
          child: Text(
            'Google calendar?',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 20,
              foreground: Paint()
                ..style = PaintingStyle.fill
                ..strokeWidth = 1
                ..color = Colors.black,
            )
            ///this makes the text center in the x and y axis in the container
          ),
        ),
      ],
    ),
    Center(
      ///widget 2
      child: Container(
        padding: EdgeInsets.all(8),
        width: double.infinity,
        child: LineChart(LineChartData(
            borderData: FlBorderData(show: true),
            lineBarsData: [
              LineChartBarData(
                isCurved: true,
                  colors: [Colors.amber],
                  spots: [
                    FlSpot(0, 1),
                    FlSpot(1, 3),
                    FlSpot(2, 10),
                    FlSpot(3, 7),
                    FlSpot(4, 12),
                    FlSpot(5, 13),
                    FlSpot(6, 17),
                    FlSpot(7, 15),
                    FlSpot(8, 20),
                  ]
              ),
              LineChartBarData(
                  isCurved: true,
                  colors: [Colors.brown],
                  spots: [
                    FlSpot(0, 3),
                    FlSpot(1, 5),
                    FlSpot(2, 7),
                    FlSpot(3, 6),
                    FlSpot(4, 17),
                    FlSpot(5, 15),
                    FlSpot(6, 12),
                    FlSpot(7, 16),
                    FlSpot(8, 22),
                  ]
              ),
            ]
        ),
        ),
      ),
    ),

    Container(
      child: Text(
        'this is impossible I swear...'
      ),
    ),

    ///widget 4
    ListView(
        padding: const EdgeInsets.all(8.0),
        children: <Widget>[
          Container(
            height: 50,
            color: Colors.amber[800],
            child: const Center(child: Text('Push Notifications'),),
          ),
          Container(
            height: 50,
            color: Colors.amber[600],
            child: const Center(child: Text('Change Password'),),
          ),
          Container(
            height: 50,
            color: Colors.amber[400],
            child: const Center(child: Text('Change Location'),),
          ),
          Container(
            height: 50,
            color: Colors.amber[200],
            child: const Center(child: Text('Languages'),),
          )
        ]
        ),

    ListView(
      padding: const EdgeInsets.all(8.0),
      children: <Widget>[
        Text('How It Works',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 20,
          ),
        ),
        Image.asset('assets/Solar16.jpg',),
        Text(''),
        Text('The following images are of the Solar Energy Research facility, and the equipment used to monitor ________',
        textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 20,
          ),
        ),
        Text(''),
        Image.asset('assets/Solar1.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar15.jpg'),
        Text('At the heart of the research facility is a solar furnace. Only 5 research facilities in the United States have a solar furnace, and Valpo is the only undergraduate institute in the United States with one. The Markiewicz Solar Energy Research Facility provides Valpo undergraduates with extraordinary engineering and research experiences and exposes College of Engineering students to solar energy engineering.',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar9.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar2.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar8.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar5.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar14.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar7.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar4.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar6.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar12.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar11.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar13.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
      ],
    )
  ];

  ///this is the on tap function used to change the selected widget
  void _onItemTapped(int index) {
    setState(() {
      ///this set state is what calls the build function of the widget state class
      _selectedIndex = index;

      ///this is the information in the state that changed
    });
  }

  ///this is what builds the state and goes over the stateless widget in the background
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      ///a scaffold is usually the root widget. it is just a blank container
      appBar: AppBar(
        ///the bar at the top is the app bar. it can contain buttons and icons
        title: const Text('Solar Energy Research Facility'),
        backgroundColor: Colors.brown
        ,
      ),
      ///the body of a scaffold is the child widget that makes up the middle part of the screen
      body: Center(
        ///a center container just centers the child widget
        child: _widgetOptions.elementAt(_selectedIndex),
        ///this is the widget in the list chosen by the state
      ),
      bottomNavigationBar: BottomNavigationBar(
        ///this is like the opposite of an app bar but has tools for navigation
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.brown,
        selectedItemColor: Colors.amber,
        unselectedItemColor: Colors.white,
        items: const <BottomNavigationBarItem>[
          ///this is a list of the items which need icons text and/or pictures
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            ///there is a massive list of icons in the Icons library
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.assessment),
            ///these aren't but they have specifically iOS icons too
            label: 'Data Review',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.videocam),
            label: 'Live Feed',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
          BottomNavigationBarItem(
           icon: Icon(Icons.info),
           label: 'About Page',
          )
        ],
        currentIndex: _selectedIndex,
        ///this is the item that is selected. will change with state change
        onTap: _onItemTapped,
        ///this is the on tap for all of the items in the navigation bar. It calls the state change
        ///and the navigation bar automatically changes the index
      ),
    );
  }
}


 