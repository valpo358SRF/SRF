<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>SERF Home</title>
    </head>
    <body>
        <div class="home">
            <a href="./login.php"><input type="button" value="Login"></a> <br>
            <a href="./register.php">Create an account</a> <br>
            <a href="./email_signup.php">Sign up for email notifications</a> <br>
        </div>
    </body>
</html>