
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';


void main() => runApp(MyApp());

///runs the entire program. Basically a main function
/// This is the main application widget.
class MyApp extends StatelessWidget {
  static const String _title = 'Flutter SERF Demo';

  @override
  Widget build(BuildContext context) {
    ///builds a blank app with an internal title and an amber background
    return MaterialApp(
      title: _title,
      theme: new ThemeData(scaffoldBackgroundColor: Colors.brown[100]),
      home: MyStatefulWidget(),
      ///this is what links it to a non static app
    );
  }
}

/// This is the stateful widget that the main application instantiates.
class MyStatefulWidget extends StatefulWidget {
  MyStatefulWidget({key}) : super(key: key);
  @override
  _MyStatefulWidgetState createState() => _MyStatefulWidgetState();
///this class calls the state to be built and returned
}
class SecondRoute extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Second Route"),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: Text('Go back!'),
        ),
      ),
    );
  }
  }

/// This is the private State class that goes with MyStatefulWidget.
class _MyStatefulWidgetState extends State<MyStatefulWidget> {
  int _selectedIndex = 0;
  ///index int
  static const TextStyle optionStyle =
  TextStyle(fontSize: 30, fontWeight: FontWeight.bold);
  ///text styling
  ///this is a list of widgets to be selected. The widgets are separated by commas
  List<Widget> _widgetOptions = <Widget>[
    Column(
      ///widget 1
      mainAxisAlignment: MainAxisAlignment.center,
      ///sets all column children to the center of the typical y axis
      children: <Widget>[
        ///list of all children cast as widgets to ensure they are
        Container(
          ///blank container used for background colors and spacing
            color: Colors.amber,
            alignment: Alignment.center,
            height: 200.0,
            width: 400.0,
            child: ElevatedButton(
              child: Text('New Page'),
              onPressed: (){

              }
            ),

        ),
      ],
    ),
    Center(
      ///widget 2
      child: Container(
        padding: EdgeInsets.all(8),
        width: double.infinity,
        child: LineChart(LineChartData(
            borderData: FlBorderData(show: true),
            lineBarsData: [
              LineChartBarData(
                  isCurved: true,
                  colors: [Colors.amber],
                  spots: [
                    FlSpot(0, 1),
                    FlSpot(1, 3),
                    FlSpot(2, 10),
                    FlSpot(3, 7),
                    FlSpot(4, 12),
                    FlSpot(5, 13),
                    FlSpot(6, 17),
                    FlSpot(7, 15),
                    FlSpot(8, 20),
                  ]
              ),
              LineChartBarData(
                  isCurved: true,
                  colors: [Colors.brown],
                  spots: [
                    FlSpot(0, 3),
                    FlSpot(1, 5),
                    FlSpot(2, 7),
                    FlSpot(3, 6),
                    FlSpot(4, 17),
                    FlSpot(5, 15),
                    FlSpot(6, 12),
                    FlSpot(7, 16),
                    FlSpot(8, 22),
                  ]
              ),
            ]
        ),
        ),
      ),
    ),

    ListView(
      padding: const EdgeInsets.all(8.0),
      children: <Widget>[
        Container(
          height: 50,
          color: Colors.amber[400],
          child: const Center(child: Text('Facts about our facility and our Sun!',
            style: TextStyle(
             fontSize: 22,
              fontStyle: FontStyle.italic,
            ),
          ),
          ),
        ),
        Text(''),
        Text('How the facility Works',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 25,
            fontStyle: FontStyle.italic,
          ),
        ),
        Image.asset('assets/Solar16.jpg',),
        Text(''),
        Text('Interesting Facts!',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 25,
            fontStyle: FontStyle.italic,
          ),
        ),
        Image.asset('assets/sun1.jpg',),
        Text('You can fit about 1.3 million Earths into the Sun!',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/sun2.jpeg',),
        Text('The mass of the sun is 333,000 times that of Earth!',
        textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/sun3.jpeg',),
        Text('The Suns surface temperature is between 5500 and 6000 celsius.',
        textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/sun4.jpeg',),
        Text('The sun is actually a mixture of ALL colors, which is why it appears to the eye as white.',
        textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/sun5.jpeg',),
        Text('Some parts of the sun are cooler than others and thus appear to be darker. They are called sunspots.'
            'Sun spots also have a very strong magnet field, which prevents the convection of energy, and thus accounts for their lower temperatures.',
        textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/sun6.jpeg',),
        Text('Composition of the sun.',
        textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/sun7.jpeg',),
        Text('When its energy (hydrogen) burns out, it will expand into the red giant and consume nearby planets, possibly even earth.',
        textAlign: TextAlign.center,
        ),
      ],
    ),

    ///widget 4
    ListView(
        padding: const EdgeInsets.all(8.0),
        children: <Widget>[
          Container(
            height: 50,
            color: Colors.amber[800],
            child: const Center(child: Text('Push Notifications'),),
          ),
          Container(
            height: 50,
            color: Colors.amber[600],
            child: const Center(child: Text('Change Password'),),
          ),
          Container(
            height: 50,
            color: Colors.amber[400],
            child: const Center(child: Text('Change Location'),),
          ),
          Container(
            height: 50,
            color: Colors.amber[200],
            child: const Center(child: Text('Languages'),),
          )
        ]
    ),

    ListView(
      padding: const EdgeInsets.all(8.0),
      children: <Widget>[
        Text(''),
        Text('The following images are of the Solar Energy Research facility, and the equipment used to monitor ________',
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 20,
          ),
        ),
        Text(''),
        Image.asset('assets/Solar1.jpg'),
        Text('The Markiewicz Solar Energy Research Facility provides Valpo undergraduates with extraordinary engineering and research experiences and exposes College of Engineering students to solar energy engineering.',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar15.jpg'),
        Text('At the heart of the facility is our solar furnace. Only 5 research facilities in the United States have a solar furnace! Valpo is the only undergraduate institute in the United States with one.',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar9.jpg'),
        Text('Our goal is to investigate processes capable of using sunlight to produce solar fuels and valuable industrial commodities.',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar2.jpg'),
        Text('View of the concentrator showing off its 306 curved mirrors.',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar8.jpg'),
        Text('The concentrator focuses the light as does a magnifying glass.',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar5.jpg'),
        Text('A solar thermal reactor is located at the focal point of the concentrated light.',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar14.jpg'),
        Text('The solar furnace is capable of generating temperatures in excess of 3,000 degrees Fahrenheit within the reactor.',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar7.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar4.jpg'),
        Text('Students conducting work on the thermal reactor.',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar6.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar12.jpg'),
        Text('The 20-foot-by-20-foot flat mirror, called the Heliostat, sits in front of the furnace building and tracks the sun, directing the light into the concentrator.',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar11.jpg'),
        Text('Another view of the Heliostat',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Image.asset('assets/Solar13.jpg'),
        Text('Text Here',
          textAlign: TextAlign.center,
        ),
        Text(''),
        Text('Endless Research Possibilities!',
        textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 25,
            fontStyle: FontStyle.italic,
          ),
        ),
        Text('The extremely high temperatures in the reactor enable a wide range of chemical reactions and therefore opens the door to a wide range of research. Valpo faculty and '
            'students will become active participants in the international effort of developing the science and engineering technology required to produce solar fuels from sunlight. '
            'Two areas that Valparaiso students and faculty are researching: Converting water into the fuel hydrogen – solar thermal decoupled water electrolysis project being conducted in '
            'conjunction with Sandia National Laboratory. Splitting zinc oxide into zinc and oxygen, without producing any waste. Zinc can be used in a fuel cell to generate electricity or as '
            'a commodity.',
        textAlign: TextAlign.center,
        ),

      ],
    )
  ];

  ///this is the on tap function used to change the selected widget
  void _onItemTapped(int index) {
    setState(() {
      ///this set state is what calls the build function of the widget state class
      _selectedIndex = index;

      ///this is the information in the state that changed
    });
  }

  ///this is what builds the state and goes over the stateless widget in the background
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      ///a scaffold is usually the root widget. it is just a blank container
      appBar: AppBar(
        ///the bar at the top is the app bar. it can contain buttons and icons
        title: const Text('Solar Energy Research Facility'),
        backgroundColor: Colors.brown
        ,
      ),
      ///the body of a scaffold is the child widget that makes up the middle part of the screen
      body: Center(
        ///a center container just centers the child widget
        child: _widgetOptions.elementAt(_selectedIndex),
        ///this is the widget in the list chosen by the state
      ),
      bottomNavigationBar: BottomNavigationBar(
        ///this is like the opposite of an app bar but has tools for navigation
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.brown,
        selectedItemColor: Colors.amber,
        unselectedItemColor: Colors.white,
        items: const <BottomNavigationBarItem>[
          ///this is a list of the items which need icons text and/or pictures
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            ///there is a massive list of icons in the Icons library
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.assessment),
            ///these aren't but they have specifically iOS icons too
            label: 'Data Review',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.wb_sunny),
            label: 'Facts',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.settings),
            label: 'Settings',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.info),
            label: 'About Page',
          )
        ],
        currentIndex: _selectedIndex,
        ///this is the item that is selected. will change with state change
        onTap: _onItemTapped,
        ///this is the on tap for all of the items in the navigation bar. It calls the state change
        ///and the navigation bar automatically changes the index
      ),
    );
  }
}
