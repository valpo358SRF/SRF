| Use Case 1 | Sign up for Notifications |
| :--- | :--- |
| Actor | User |
| Subject Area |  |
| Basic Flow |  |
| Alternative Flow _n_ |  |


**Notes:** 
- Might remove Subject Area
